from assignment3 import products, bakery
